<template>
  <div>
    <h1>About Page</h1>
    <p>This is the about page of our Nuxt.js application.</p>
    <nuxt-link to="/">Go back to Home</nuxt-link>
  </div>
</template>

<script setup>
</script>

<style scoped>
h1 {
  color: #ff6347;
  text-align: center;
}
p {
  text-align: center;
}
</style>
