<template>
  <div>
    <NuxtRouteAnnouncer />
    
  </div>
  <NuxtLayout>
  <NuxtPage />
</NuxtLayout>
</template>
